# Disaster Optimizer Pro (Google Maps + MySQL)

### Setup Instructions
1. **Install MySQL**: Ensure MySQL is running on your machine.
2. **Create Database**: Run the code in `schema.sql` to create `disaster_db`.
3. **Environment Variables**:
   - `export GOOGLE_MAPS_API_KEY="your_key"`
   - `export HF_API_TOKEN="your_huggingface_token"`
   - Update `DATABASE_URL` in `app.py` with your MySQL credentials.
4. **Install Deps**: `pip install -r requirements.txt`
5. **Run**: `python app.py`

### Features
- Persistent MySQL storage for zones and depots.
- Real-world mapping using Google Maps API.
- Click-to-place markers for disaster zones.
