-- SQL Schema for Disaster Supply Chain Optimizer
CREATE DATABASE IF NOT EXISTS disaster_db;
USE disaster_db;

CREATE TABLE IF NOT EXISTS depots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL
);

CREATE TABLE IF NOT EXISTS zones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    population INT NOT NULL,
    severity INT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL
);

CREATE TABLE IF NOT EXISTS supplies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    unit VARCHAR(20),
    depot_id INT,
    FOREIGN KEY (depot_id) REFERENCES depots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    zone_id INT,
    food_alloc INT,
    water_alloc INT,
    meds_alloc INT,
    risk_level VARCHAR(20),
    FOREIGN KEY (zone_id) REFERENCES zones(id) ON DELETE CASCADE
);

-- Seed Data
INSERT INTO depots (name, latitude, longitude) VALUES 
('Depot Alpha', 19.0760, 72.8777),
('Depot Beta', 18.5204, 73.8567);
