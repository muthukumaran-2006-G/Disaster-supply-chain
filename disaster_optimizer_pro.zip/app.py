from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import os
import requests

app = Flask(__name__)

# Database Configuration (MySQL)
# Format: mysql+pymysql://user:password@host/dbname
app.config['SQLALCHEMY_DATABASE_DATABASE'] = 'disaster_db'
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'mysql+pymysql://root:password@localhost/disaster_db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Models
class Zone(db.Model):
    __tablename__ = 'zones'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    population = db.Column(db.Integer)
    severity = db.Column(db.Integer)
    latitude = db.Column(db.Numeric(10, 8))
    longitude = db.Column(db.Numeric(11, 8))

class Depot(db.Model):
    __tablename__ = 'depots'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    latitude = db.Column(db.Numeric(10, 8))
    longitude = db.Column(db.Numeric(11, 8))

# AI Config
HF_API_TOKEN = os.environ.get("HF_API_TOKEN", "your_token_here")
HF_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"
HF_API_URL = f"https://api-inference.huggingface.co/models/{HF_MODEL}"

@app.route('/')
def index():
    return render_template('index.html', google_maps_api_key=os.environ.get('GOOGLE_MAPS_API_KEY', 'YOUR_KEY_HERE'))

@app.route('/api/zones', methods=['GET', 'POST'])
def manage_zones():
    if request.method == 'POST':
        data = request.json
        new_zone = Zone(name=data['name'], population=data['population'], 
                        severity=data['severity'], latitude=data['latitude'], longitude=data['longitude'])
        db.session.add(new_zone)
        db.session.commit()
        return jsonify({"message": "Zone added"}), 201
    zones = Zone.query.all()
    return jsonify([{"id": z.id, "name": z.name, "lat": float(z.latitude), "lng": float(z.longitude), "severity": z.severity} for z in zones])

@app.route('/api/optimize', methods=['POST'])
def optimize():
    zones = Zone.query.all()
    depots = Depot.query.all()
    
    # Logic: Simple proportional allocation (reused from prototype logic)
    results = []
    for z in zones:
        demand_score = z.population * z.severity
        results.append({
            "zone": z.name,
            "food": round(demand_score * 0.004),
            "water": round(demand_score * 0.0025)
        })
    
    # AI Suggestions call
    prompt = f"System: Disaster Logistics Expert. Context: {len(zones)} zones affected. Suggest 3 priority actions."
    headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}
    ai_text = "AI suggestion unavailable (check API key)"
    try:
        resp = requests.post(HF_API_URL, headers=headers, json={"inputs": prompt}, timeout=5)
        if resp.status_code == 200:
            ai_text = resp.json()[0]['generated_text']
    except:
        pass

    return jsonify({"allocations": results, "ai_suggestion": ai_text})

if __name__ == '__main__':
    app.run(debug=True)
