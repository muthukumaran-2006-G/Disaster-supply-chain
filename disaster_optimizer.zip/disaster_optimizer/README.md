# ⚡ AI-Based Disaster Supply Chain Optimizer

A hackathon-ready web application that simulates relief supply distribution during natural disasters,
powered by Flask, Tailwind CSS, and the Hugging Face Inference API.

---

## 📁 Folder Structure

```
disaster_optimizer/
├── app.py                  ← Flask backend (all logic here)
├── requirements.txt        ← Python dependencies
├── README.md               ← This file
└── templates/
    └── index.html          ← Full frontend (Tailwind + Vanilla JS)
```

---

## 🚀 Quick Start (Local Setup)

### 1. Prerequisites
- Python 3.8+
- pip

### 2. Install Dependencies

```bash
cd disaster_optimizer
pip install -r requirements.txt
```

### 3. (Optional) Set Hugging Face API Token

Get a free token at https://huggingface.co/settings/tokens

**Option A — Environment variable (recommended):**
```bash
# Mac/Linux
export HF_API_TOKEN="hf_your_token_here"

# Windows CMD
set HF_API_TOKEN=hf_your_token_here

# Windows PowerShell
$env:HF_API_TOKEN="hf_your_token_here"
```

**Option B — Edit app.py directly:**
```python
# Line 16 in app.py
HF_API_TOKEN = "hf_your_token_here"
```

> ⚠️ If no token is set, the app automatically falls back to a built-in rule-based suggestion engine — it still works, just without the LLM.

### 4. Run the App

```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## 🎮 How to Use

### Quick Demo
1. Click **"🌪 Simulate Disaster"** — auto-fills 5 zones, 3 depots, supplies
2. Click **"▶ Run Optimizer"** — runs allocation + routing + AI suggestions
3. View results in the dashboard below

### Manual Input
1. **Add Zones** — click "+ Add" in the Affected Zones card
   - Enter name, population, severity (1–10), and map coordinates (X/Y 0–100)
2. **Set Supplies** — enter available food (kg), water (liters), medicines (units)
3. **Add Depots** — click "+ Add" in the Depot Locations card
   - Enter depot name and map coordinates
4. **Run Optimizer** — click the button; results appear below

---

## ⚙️ How It Works

### Demand Calculation
```
demand_score = population × severity
food_needed  = demand_score × 0.004
water_needed = demand_score × 0.0025
meds_needed  = demand_score × 0.0004
```

### Allocation Strategy
- Proportional share of available supplies based on `demand_score`
- Higher severity → larger share
- Gaps are tracked per resource type

### Risk Classification
| Gap Ratio | Risk Level |
|-----------|------------|
| > 50%     | CRITICAL   |
| > 20%     | HIGH       |
| > 0%      | MEDIUM     |
| 0%        | LOW        |

### Route Optimization
- Euclidean distance from each zone to all depots
- Nearest depot is assigned per zone
- Estimated travel time at 40 km/h average

### AI Suggestions (Hugging Face)
- Uses `mistralai/Mistral-7B-Instruct-v0.2` via Inference API
- Sends compact situation summary as prompt
- Falls back to rule-based suggestions if API unavailable/slow

---

## 🧪 Sample Mock Data (auto-filled by Simulate button)

| Zone                | Population | Severity |
|---------------------|-----------|----------|
| Zone A - Coastal City | 45,000  | 9        |
| Zone B - Hill Village | 12,000  | 7        |
| Zone C - River Town   | 28,000  | 8        |
| Zone D - Mountain Camp| 5,000   | 6        |
| Zone E - Plains District | 33,000| 5      |

Supplies: 500,000 kg food · 300,000 L water · 50,000 medicine units
Depots: Alpha (North), Beta (East), Gamma (South)

---

## 🔌 API Endpoints

| Method | URL              | Description                          |
|--------|------------------|--------------------------------------|
| GET    | `/`              | Serve frontend dashboard             |
| GET    | `/api/simulate`  | Return sample disaster data (JSON)   |
| POST   | `/api/optimize`  | Run full optimization, return results|

### POST `/api/optimize` Request Body
```json
{
  "zones": [
    {"name": "Zone A", "population": 45000, "severity": 9}
  ],
  "supplies": {
    "food":      {"quantity": 500000, "unit": "kg"},
    "water":     {"quantity": 300000, "unit": "liters"},
    "medicines": {"quantity": 50000,  "unit": "units"}
  },
  "depots": [
    {"name": "Depot Alpha", "x": 10, "y": 80}
  ],
  "zone_coords": [{"x": 20, "y": 90}]
}
```

---

## 🛠 Tech Stack

| Layer      | Technology                             |
|-----------|----------------------------------------|
| Frontend  | HTML + Tailwind CSS (CDN) + Vanilla JS |
| Backend   | Flask (Python)                         |
| AI/LLM    | Hugging Face Inference API (Mistral-7B)|
| Routing   | Euclidean nearest-depot algorithm      |
| Allocation| Priority-based proportional greedy     |

> **Note on MySQL:** The current prototype uses in-memory processing for hackathon speed. To add MySQL persistence, install `flask-sqlalchemy` and `pymysql`, create a `models.py` with `Zone`, `Supply`, `Depot` tables, and replace the in-request data flow with DB reads/writes. The modular structure in `app.py` makes this straightforward to add.

---

## 🎯 Extending the Project

- **Add MySQL** — store historical scenarios, compare runs over time
- **Leaflet.js map** — replace canvas with real interactive map using lat/lng
- **WebSocket updates** — live allocation updates as disaster evolves
- **Multi-depot routing** — split loads across depots using LP solver
- **More AI models** — swap HF model or add OpenAI/Claude API

---

## 📄 License
MIT — free to use, modify, and submit to hackathons!
